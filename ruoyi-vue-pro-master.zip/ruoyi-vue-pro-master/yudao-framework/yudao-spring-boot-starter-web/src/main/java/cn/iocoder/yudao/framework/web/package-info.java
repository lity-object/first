/**
 * 针对 SpringMVC 的基础封装
 */
package cn.iocoder.yudao.framework.web;

/**
 * 使用 SkyWalking 组件，作为链路追踪、日志中心。
 *
 * @author 芋道源码
 */
package cn.iocoder.yudao.framework.tracer;

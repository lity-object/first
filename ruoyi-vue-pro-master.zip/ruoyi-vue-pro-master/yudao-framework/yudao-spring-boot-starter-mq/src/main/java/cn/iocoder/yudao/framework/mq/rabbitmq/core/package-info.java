/**
 * 占位符，无特殊逻辑
 */
package cn.iocoder.yudao.framework.mq.rabbitmq.core;
/**
 * 基于部门的数据权限规则
 *
 * @author 芋道源码
 */
package cn.iocoder.yudao.framework.datapermission.core.rule.dept;

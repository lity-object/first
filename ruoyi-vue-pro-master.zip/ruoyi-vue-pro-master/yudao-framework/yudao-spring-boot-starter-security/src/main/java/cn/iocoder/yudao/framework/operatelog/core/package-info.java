/**
 * 占位，无特殊作用
 */
package cn.iocoder.yudao.framework.operatelog.core;